# SecondBrain Paper Plugin - README
> Original Fabric mod by **sailex428**: https://github.com/sailex428/SecondBrain  
> Ported to Paper 1.21.x with **xnetwork-api (OpenAI-compatible)** support

---

## ✅ Installation

1. Drop **`SecondBrain-1.0.0.jar`** into your server's `plugins/` folder
2. Start/restart the server - a `plugins/SecondBrain/config.yml` will be generated
3. Open `config.yml` and paste your API key under `llm.api-key`
4. Restart or run `/sb reload`

---

## ⚙️ config.yml

```yaml
llm:
  url: "https://ai.xnetwork.ro/v1"   # AI endpoint
  model: "gpt-oss-20b"               # Model name
  api-key: "PUT_YOUR_API_KEY_HERE"   # YOUR API KEY HERE
  timeout: 30                        # Seconds

npc:
  default-system-prompt: "You are {name}, a helpful Minecraft NPC."
  chat-radius: 10          # Blocks radius to detect chat
  respond-to-all: true     # true = respond to any chat nearby
                           # false = only respond if chat starts with NPC name
```

---

## 📋 Commands

| Command | Description |
|---------|-------------|
| `/sb` | Open the Inventory GUI |
| `/sb create <name>` | Create an NPC at your location |
| `/sb remove <name>` | Remove an NPC |
| `/sb list` | List all NPCs |
| `/sb info <name>` | Show NPC details |
| `/sb setprompt <name> <text>` | Change an NPC's personality/prompt |
| `/sb clearmemory <name>` | Clear an NPC's conversation history |
| `/sb setkey <api_key>` | Set API key without editing config |
| `/sb reload` | Reload config.yml |

**Aliases:** `/secondbrain`, `/sb`

---

## 🖥️ GUI Usage

Run `/sb` to open the GUI:
- Click **NPC List** → View all created NPCs
- Left-Click on an NPC card → Delete it
- Right-Click on an NPC card → Clear its memory
- Click **Create NPC** → Type a name in chat to create an NPC at your location

---

## 💬 Interacting with NPCs

Just walk within the configured radius (default: 10 blocks) and type in chat!  
The NPC will respond using the AI.

To talk to a specific NPC only, set `respond-to-all: false` in config.yml.  
Then prefix your message with the NPC's name: e.g. `Steve hello!`

---

## 🔑 Permissions

| Permission | Default | Description |
|-----------|---------|-------------|
| `secondbrain.use` | op | Use `/sb`, `/sb list`, `/sb info` |
| `secondbrain.admin` | op | Create/remove NPCs, setkey, setprompt, reload |

---

## 📜 License
This plugin is based on SecondBrain by **sailex428**, licensed under **LGPL-3.0**.  
See `LICENSE.md` for full details.
