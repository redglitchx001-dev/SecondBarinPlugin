package me.sailex.secondbrain.npc;

import me.sailex.secondbrain.SecondBrainPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class NPCManager {
    private final SecondBrainPlugin plugin;
    private final Map<String, NPCData> npcs = new ConcurrentHashMap<>();
    private final File dataFile;
    private FileConfiguration dataConfig;

    public NPCManager(SecondBrainPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "npcs.yml");
        loadAll();
        startLookTask();
    }

    public void createNPC(String name, Location loc) {
        String id = UUID.randomUUID().toString().substring(0, 8);
        String prompt = plugin.getConfigManager().getDefaultPrompt().replace("{name}", name);
        NPCData data = new NPCData(id, name, loc, prompt);
        npcs.put(name.toLowerCase(), data);
        spawnEntity(data);
        saveAll();
    }

    private void spawnEntity(NPCData data) {
        if (data.getLocation().getWorld() == null) return;
        
        // Remove old entity if exists
        if (data.getEntityUuid() != null) {
            Entity old = Bukkit.getEntity(data.getEntityUuid());
            if (old != null) old.remove();
        }

        Villager v = (Villager) data.getLocation().getWorld().spawnEntity(data.getLocation(), EntityType.VILLAGER);
        v.setAI(false);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setCollidable(false);
        v.setCustomName("§e§l" + data.getName());
        v.setCustomNameVisible(true);
        v.setPersistent(true);
        v.addScoreboardTag("secondbrain_npc");
        
        data.setEntityUuid(v.getUniqueId());
    }

    public boolean removeByName(String name) {
        NPCData data = npcs.remove(name.toLowerCase());
        if (data == null) return false;
        
        if (data.getEntityUuid() != null) {
            Entity e = Bukkit.getEntity(data.getEntityUuid());
            if (e != null) e.remove();
        }
        
        dataConfig.set("npcs." + data.getId(), null);
        try { dataConfig.save(dataFile); } catch (IOException ignored) {}
        return true;
    }

    public boolean setSystemPrompt(String name, String prompt) {
        NPCData data = npcs.get(name.toLowerCase());
        if (data == null) return false;
        data.setSystemPrompt(prompt);
        saveAll();
        return true;
    }

    public NPCData findByName(String name) {
        return npcs.get(name.toLowerCase());
    }

    public Map<String, NPCData> getAllNPCs() {
        return npcs;
    }

    private void loadAll() {
        if (!dataFile.exists()) {
            try { dataFile.createNewFile(); } catch (IOException ignored) {}
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        if (!dataConfig.contains("npcs")) return;

        for (String id : dataConfig.getConfigurationSection("npcs").getKeys(false)) {
            String path = "npcs." + id + ".";
            String name = dataConfig.getString(path + "name");
            Location loc = dataConfig.getLocation(path + "location");
            String prompt = dataConfig.getString(path + "prompt");
            
            NPCData data = new NPCData(id, name, loc, prompt);
            npcs.put(name.toLowerCase(), data);
            
            // Clean up any stray entities from previous crashes then respawn
            for (Entity e : loc.getWorld().getEntitiesByClass(Villager.class)) {
                if (e.getScoreboardTags().contains("secondbrain_npc") && 
                    e.getCustomName() != null && e.getCustomName().contains(name)) {
                    e.remove();
                }
            }
            spawnEntity(data);
        }
    }

    public void saveAll() {
        for (NPCData data : npcs.values()) {
            String path = "npcs." + data.getId() + ".";
            dataConfig.set(path + "name", data.getName());
            dataConfig.set(path + "location", data.getLocation());
            dataConfig.set(path + "prompt", data.getSystemPrompt());
        }
        try { dataConfig.save(dataFile); } catch (IOException ignored) {}
    }

    // Makes NPCs look at the nearest player
    private void startLookTask() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (NPCData data : npcs.values()) {
                if (data.getEntityUuid() == null) continue;
                Entity e = Bukkit.getEntity(data.getEntityUuid());
                if (e == null || !e.isValid()) {
                    spawnEntity(data); // Respawn if missing
                    continue;
                }
                
                Player nearest = null;
                double minDist = 100.0;
                for (Player p : e.getWorld().getPlayers()) {
                    double d = p.getLocation().distanceSquared(e.getLocation());
                    if (d < minDist) { minDist = d; nearest = p; }
                }
                
                if (nearest != null) {
                    Vector dir = nearest.getEyeLocation().toVector().subtract(e.getLocation().toVector()).normalize();
                    Location loc = e.getLocation();
                    loc.setDirection(dir);
                    e.setRotation(loc.getYaw(), loc.getPitch());
                }
            }
        }, 0L, 5L);
    }
}
