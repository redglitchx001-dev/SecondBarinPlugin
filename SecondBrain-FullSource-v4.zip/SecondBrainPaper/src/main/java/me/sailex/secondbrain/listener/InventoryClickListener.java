package me.sailex.secondbrain.listener;

import io.papermc.paper.event.player.AsyncChatEvent;
import me.sailex.secondbrain.SecondBrainPlugin;
import me.sailex.secondbrain.npc.NPCData;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class InventoryClickListener implements Listener {
    private final SecondBrainPlugin plugin;
    private final Set<UUID> pendingCreate = new HashSet<>();

    public InventoryClickListener(SecondBrainPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        String t = PlainTextComponentSerializer.plainText().serialize(e.getView().title());

        if (t.contains("Menu")) {
            e.setCancelled(true);
            ItemStack i = e.getCurrentItem();
            if (i == null || !i.hasItemMeta()) return;
            String n = PlainTextComponentSerializer.plainText().serialize(i.getItemMeta().displayName());
            if (n.contains("Manage")) plugin.getGuiManager().openNPCList(p);
            else if (n.contains("Create")) {
                p.closeInventory();
                p.sendMessage(plugin.getConfigManager().msgRaw("prefix") + "§fType NPC §ename§f in chat:");
                pendingCreate.add(p.getUniqueId());
            }
        } else if (t.contains("NPCs")) {
            e.setCancelled(true);
            ItemStack i = e.getCurrentItem();
            if (i == null || !i.hasItemMeta()) return;
            String n = PlainTextComponentSerializer.plainText().serialize(i.getItemMeta().displayName()).trim();
            if (n.equals("Back")) { plugin.getGuiManager().openMainMenu(p); return; }
            if (i.getType().name().contains("GLASS") || i.getType() == Material.BARRIER) return;

            if (e.isLeftClick()) {
                plugin.getNpcManager().removeByName(n);
                p.sendMessage(plugin.getConfigManager().msg("removed").replace("{name}", n));
                plugin.getGuiManager().openNPCList(p);
            }
        }
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID u = p.getUniqueId();
        String m = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();

        if (pendingCreate.contains(u)) {
            e.setCancelled(true);
            pendingCreate.remove(u);
            if (m.isEmpty()) return;
            Bukkit.getScheduler().runTask(plugin, () -> {
                plugin.getNpcManager().createNPC(m, p.getLocation());
                p.sendMessage(plugin.getConfigManager().msg("created").replace("{name}", m));
            });
        }
    }
}
