package me.sailex.secondbrain.llm;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import me.sailex.secondbrain.SecondBrainPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class LLMClient {

    private HttpClient http;

    public LLMClient(SecondBrainPlugin plugin) { reload(); }

    public void reload() {
        this.http = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    public static CompletableFuture<String> chat(SecondBrainPlugin plugin, String systemPrompt,
                                                 String playerName, String message,
                                                 List<Map<String, String>> history) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                String apiKey = plugin.getConfigManager().getApiKey();
                if (apiKey.equals("PUT_YOUR_API_KEY_HERE") || apiKey.isBlank()) {
                    return plugin.getConfigManager().msgRaw("no-key");
                }

                String apiUrl = plugin.getConfigManager().getApiUrl().replaceAll("/$", "") + "/chat/completions";
                String model = plugin.getConfigManager().getApiModel();
                int timeout = plugin.getConfigManager().getTimeout();

                JsonObject payload = new JsonObject();
                payload.addProperty("model", model);
                payload.addProperty("max_tokens", 250);
                payload.addProperty("temperature", 0.8);

                JsonArray msgs = new JsonArray();
                msgs.add(makeMsg("system", systemPrompt));
                for (Map<String, String> m : history) msgs.add(makeMsg(m.get("role"), m.get("content")));

                String userContent = playerName + ": " + message;
                msgs.add(makeMsg("user", userContent));
                payload.add("messages", msgs);

                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(apiUrl))
                        .timeout(Duration.ofSeconds(timeout))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + apiKey)
                        .POST(HttpRequest.BodyPublishers.ofString(payload.toString()))
                        .build();

                HttpResponse<String> resp = plugin.getLlmClient().http.send(req, HttpResponse.BodyHandlers.ofString());

                if (resp.statusCode() == 200) {
                    String reply = JsonParser.parseString(resp.body()).getAsJsonObject()
                            .getAsJsonArray("choices").get(0).getAsJsonObject()
                            .getAsJsonObject("message").get("content").getAsString().trim();

                    history.add(makeMap("user", userContent));
                    history.add(makeMap("assistant", reply));
                    return reply;
                } else {
                    return "§c[AI Error " + resp.statusCode() + "] Bad API key or endpoint.";
                }
            } catch (Exception e) {
                return "§c[SecondBrain] Network error to AI server.";
            }
        });
    }

    private static JsonObject makeMsg(String role, String content) {
        JsonObject o = new JsonObject();
        o.addProperty("role", role);
        o.addProperty("content", content);
        return o;
    }

    private static Map<String, String> makeMap(String role, String content) {
        Map<String, String> m = new HashMap<>();
        m.put("role", role);
        m.put("content", content);
        return m;
    }
}
