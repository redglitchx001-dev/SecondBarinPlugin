package me.sailex.secondbrain.config;

import me.sailex.secondbrain.SecondBrainPlugin;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
    private final SecondBrainPlugin plugin;
    private FileConfiguration cfg;

    public ConfigManager(SecondBrainPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        plugin.reloadConfig();
        cfg = plugin.getConfig();
    }

    public String getApiUrl()    { return cfg.getString("llm.url", "https://ai.xnetwork.ro/v1"); }
    public String getApiModel()  { return cfg.getString("llm.model", "gpt-oss-20b"); }
    public String getApiKey()    { return cfg.getString("llm.api-key", "PUT_YOUR_API_KEY_HERE"); }
    public int    getTimeout()   { return cfg.getInt("llm.timeout", 30); }
    public int    getMaxHistory(){ return cfg.getInt("llm.max-history", 20); }

    public void setApiKey(String key) { cfg.set("llm.api-key", key); plugin.saveConfig(); }

    public String  getDefaultPrompt()    { return cfg.getString("npc.default-prompt", "You are {name}"); }
    public double  getChatRadius()       { return cfg.getDouble("npc.chat-radius", 15.0); }
    
    // Toggles
    public boolean isRespondOnlyToName() { return cfg.getBoolean("npc.respond-only-to-name", true); }
    public void setRespondOnlyToName(boolean v) { cfg.set("npc.respond-only-to-name", v); plugin.saveConfig(); }

    public boolean isChatEnabled() { return cfg.getBoolean("npc.chat-enabled", true); }
    public void setChatEnabled(boolean v) { cfg.set("npc.chat-enabled", v); plugin.saveConfig(); }

    public String getChatFormat() { return cfg.getString("chat.format", "§8<§e{npc}§8> §f{msg}"); }

    public String msg(String key) {
        String prefix = color(cfg.getString("messages.prefix", "§8[§bSecondBrain§8] §r"));
        return prefix + color(cfg.getString("messages." + key, "§cMsg missing: " + key));
    }
    public String msgRaw(String key) {
        return color(cfg.getString("messages." + key, "§cMsg missing: " + key));
    }
    public static String color(String s) { return s == null ? "" : s.replace("&", "\u00a7"); }
}
