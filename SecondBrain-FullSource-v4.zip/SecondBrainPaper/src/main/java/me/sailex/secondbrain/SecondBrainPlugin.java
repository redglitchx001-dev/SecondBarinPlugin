package me.sailex.secondbrain;

import me.sailex.secondbrain.command.SecondBrainCommand;
import me.sailex.secondbrain.config.ConfigManager;
import me.sailex.secondbrain.gui.GUIManager;
import me.sailex.secondbrain.listener.ChatListener;
import me.sailex.secondbrain.listener.InventoryClickListener;
import me.sailex.secondbrain.llm.LLMClient;
import me.sailex.secondbrain.npc.NPCManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SecondBrainPlugin extends JavaPlugin {
    private static SecondBrainPlugin instance;
    private ConfigManager configManager;
    private LLMClient llmClient;
    private NPCManager npcManager;
    private GUIManager guiManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        configManager = new ConfigManager(this);
        llmClient = new LLMClient(this);
        npcManager = new NPCManager(this);
        guiManager = new GUIManager(this);

        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new InventoryClickListener(this), this);

        SecondBrainCommand cmd = new SecondBrainCommand(this);
        getCommand("secondbrain").setExecutor(cmd);
        getCommand("secondbrain").setTabCompleter(cmd);

        getLogger().info("SecondBrain v4.0 Enabled! (Custom Engine - No Dependencies)");
    }

    @Override
    public void onDisable() {
        if (npcManager != null) npcManager.saveAll();
    }

    public void reload() {
        reloadConfig();
        configManager.reload();
        llmClient.reload();
    }

    public static SecondBrainPlugin getInstance() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public LLMClient getLlmClient() { return llmClient; }
    public NPCManager getNpcManager() { return npcManager; }
    public GUIManager getGuiManager() { return guiManager; }
}
