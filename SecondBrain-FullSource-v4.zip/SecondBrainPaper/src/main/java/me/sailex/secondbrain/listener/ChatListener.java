package me.sailex.secondbrain.listener;

import io.papermc.paper.event.player.AsyncChatEvent;
import me.sailex.secondbrain.SecondBrainPlugin;
import me.sailex.secondbrain.llm.LLMClient;
import me.sailex.secondbrain.npc.NPCData;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class ChatListener implements Listener {
    private final SecondBrainPlugin plugin;
    private final Map<UUID, Set<String>> pending = new ConcurrentHashMap<>();
    private final Map<String, List<Map<String, String>>> histories = new ConcurrentHashMap<>();

    public ChatListener(SecondBrainPlugin plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.getConfigManager().isChatEnabled()) return;

        Player player = event.getPlayer();
        String msg = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        double radius = plugin.getConfigManager().getChatRadius();
        boolean nameOnly = plugin.getConfigManager().isRespondOnlyToName();

        for (NPCData data : plugin.getNpcManager().getAllNPCs().values()) {
            Entity ent = Bukkit.getEntity(data.getEntityUuid());
            if (ent == null || !ent.isValid()) continue;
            if (!ent.getWorld().equals(player.getWorld())) continue;
            if (ent.getLocation().distance(player.getLocation()) > radius) continue;

            if (nameOnly && !msg.toLowerCase().contains(data.getName().toLowerCase())) continue;

            Set<String> activeForPlayer = pending.computeIfAbsent(player.getUniqueId(), k -> new HashSet<>());
            if (activeForPlayer.contains(data.getId())) continue;
            
            activeForPlayer.add(data.getId());

            String histKey = player.getUniqueId().toString() + "_" + data.getId();
            List<Map<String, String>> history = histories.computeIfAbsent(histKey, k -> new ArrayList<>());
            
            int max = plugin.getConfigManager().getMaxHistory();
            while (history.size() > max) history.remove(0);

            LLMClient.chat(plugin, data.getSystemPrompt(), player.getName(), msg, history)
                .thenAccept(reply -> Bukkit.getScheduler().runTask(plugin, () -> {
                    activeForPlayer.remove(data.getId());
                    
                    String format = plugin.getConfigManager().getChatFormat()
                            .replace("{npc}", data.getName())
                            .replace("{msg}", reply);

                    double rad = plugin.getConfigManager().getChatRadius() * 3;
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        if (p.getWorld().equals(ent.getWorld()) && p.getLocation().distance(ent.getLocation()) <= rad) {
                            p.sendMessage(format);
                        }
                    }
                }));
        }
    }

    public void clearMemory(String npcId) {
        histories.keySet().removeIf(k -> k.endsWith("_" + npcId));
    }
}
