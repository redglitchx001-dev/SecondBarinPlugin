package me.sailex.secondbrain.command;

import me.sailex.secondbrain.SecondBrainPlugin;
import me.sailex.secondbrain.npc.NPCData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SecondBrainCommand implements CommandExecutor, TabCompleter {
    private final SecondBrainPlugin plugin;

    public SecondBrainCommand(SecondBrainPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] args) {
        if (args.length == 0) {
            if (s instanceof Player p) plugin.getGuiManager().openMainMenu(p);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "create" -> {
                if (!perm(s, "secondbrain.admin")) return true;
                if (!(s instanceof Player p)) return true;
                if (args.length < 2) { s.sendMessage("§c/sb create <name>"); return true; }
                plugin.getNpcManager().createNPC(args[1], p.getLocation());
                s.sendMessage(plugin.getConfigManager().msg("created").replace("{name}", args[1]));
            }
            case "remove" -> {
                if (!perm(s, "secondbrain.admin")) return true;
                if (args.length < 2) return true;
                if (plugin.getNpcManager().removeByName(args[1]))
                    s.sendMessage(plugin.getConfigManager().msg("removed").replace("{name}", args[1]));
                else s.sendMessage(plugin.getConfigManager().msg("not-found").replace("{name}", args[1]));
            }
            case "list" -> {
                if (!perm(s, "secondbrain.use")) return true;
                s.sendMessage(plugin.getConfigManager().msgRaw("list-header"));
                var list = plugin.getNpcManager().getAllNPCs().values();
                if (list.isEmpty()) s.sendMessage(plugin.getConfigManager().msg("list-empty"));
                for (NPCData n : list) {
                    s.sendMessage(plugin.getConfigManager().msg("list-entry").replace("{name}", n.getName())
                            .replace("{world}", n.getLocation().getWorld() != null ? n.getLocation().getWorld().getName() : "none"));
                }
            }
            case "setprompt" -> {
                if (!perm(s, "secondbrain.admin") || args.length < 3) return true;
                String p = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                if (plugin.getNpcManager().setSystemPrompt(args[1], p))
                    s.sendMessage(plugin.getConfigManager().msg("prompt-set").replace("{name}", args[1]));
            }
            case "toggle" -> {
                if (!perm(s, "secondbrain.admin") || args.length < 3) {
                    s.sendMessage("§c/sb toggle <nameonly|chat> <true|false>");
                    return true;
                }
                boolean val = Boolean.parseBoolean(args[2]);
                if (args[1].equalsIgnoreCase("nameonly")) {
                    plugin.getConfigManager().setRespondOnlyToName(val);
                    s.sendMessage(plugin.getConfigManager().msgRaw("toggle-nameonly").replace("{value}", String.valueOf(val)));
                } else if (args[1].equalsIgnoreCase("chat")) {
                    plugin.getConfigManager().setChatEnabled(val);
                    s.sendMessage(plugin.getConfigManager().msgRaw("toggle-chat").replace("{value}", String.valueOf(val)));
                } else {
                    s.sendMessage("§cInvalid setting. Use 'nameonly' or 'chat'.");
                }
            }
            case "setkey" -> {
                if (!perm(s, "secondbrain.admin") || args.length < 2) return true;
                plugin.getConfigManager().setApiKey(args[1]);
                plugin.getLlmClient().reload();
                s.sendMessage(plugin.getConfigManager().msg("key-saved"));
            }
            case "reload" -> {
                if (!perm(s, "secondbrain.admin")) return true;
                plugin.reload();
                s.sendMessage(plugin.getConfigManager().msg("reloaded"));
            }
            default -> {
                s.sendMessage("§8=== §bSecondBrain Commands §8===");
                s.sendMessage("§e/sb create <name> §8- Create NPC");
                s.sendMessage("§e/sb remove <name> §8- Remove NPC");
                s.sendMessage("§e/sb list §8- List NPCs");
                s.sendMessage("§e/sb setprompt <name> <txt> §8- Change prompt");
                s.sendMessage("§e/sb toggle <nameonly|chat> <true/false> §8- Change settings");
                s.sendMessage("§e/sb setkey <key> §8- Set API Key");
            }
        }
        return true;
    }

    private boolean perm(CommandSender s, String p) {
        if (s.hasPermission(p)) return true;
        s.sendMessage(plugin.getConfigManager().msg("no-perm"));
        return false;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String cmd : List.of("create","remove","list","setprompt","toggle","setkey","reload"))
                if (cmd.startsWith(args[0].toLowerCase())) out.add(cmd);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("toggle")) {
            for (String sub : List.of("nameonly", "chat"))
                if (sub.startsWith(args[1].toLowerCase())) out.add(sub);
        } else if (args.length == 3 && args[0].equalsIgnoreCase("toggle")) {
            for (String sub : List.of("true", "false"))
                if (sub.startsWith(args[2].toLowerCase())) out.add(sub);
        }
        return out;
    }
}
