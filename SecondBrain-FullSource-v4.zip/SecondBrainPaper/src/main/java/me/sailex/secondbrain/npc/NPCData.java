package me.sailex.secondbrain.npc;

import org.bukkit.Location;
import java.util.UUID;

public class NPCData {
    private final String id;
    private String name;
    private Location location;
    private String systemPrompt;
    private UUID entityUuid; // UUID of the actual Bukkit Entity

    public NPCData(String id, String name, Location location, String systemPrompt) {
        this.id = id;
        this.name = name;
        this.location = location;
        this.systemPrompt = systemPrompt;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    public String getSystemPrompt() { return systemPrompt; }
    public void setSystemPrompt(String systemPrompt) { this.systemPrompt = systemPrompt; }
    public UUID getEntityUuid() { return entityUuid; }
    public void setEntityUuid(UUID entityUuid) { this.entityUuid = entityUuid; }
}
