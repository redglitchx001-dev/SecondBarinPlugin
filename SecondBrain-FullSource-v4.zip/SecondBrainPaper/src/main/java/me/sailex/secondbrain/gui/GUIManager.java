package me.sailex.secondbrain.gui;

import me.sailex.secondbrain.SecondBrainPlugin;
import me.sailex.secondbrain.npc.NPCData;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class GUIManager {
    public static final String TITLE_MAIN = "§0[§bSecondBrain§0] Menu";
    public static final String TITLE_NPCS = "§0[§bSecondBrain§0] NPCs";
    private final SecondBrainPlugin plugin;

    public GUIManager(SecondBrainPlugin plugin) { this.plugin = plugin; }

    public void openMainMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(TITLE_MAIN));
        fill(inv, 27, Material.BLACK_STAINED_GLASS_PANE);

        inv.setItem(11, makeItem(Material.VILLAGER_SPAWN_EGG, "§a§lManage NPCs", "§7List all NPCs"));
        inv.setItem(15, makeItem(Material.EMERALD, "§b§lCreate NPC Here", "§7Type name in chat after clicking"));

        player.openInventory(inv);
    }

    public void openNPCList(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, Component.text(TITLE_NPCS));
        fillRow(inv, 0, Material.CYAN_STAINED_GLASS_PANE);
        fillRow(inv, 5, Material.CYAN_STAINED_GLASS_PANE);

        var npcs = plugin.getNpcManager().getAllNPCs().values();
        if (npcs.isEmpty()) {
            inv.setItem(22, makeItem(Material.BARRIER, "§cNo NPCs exist"));
        } else {
            int slot = 10;
            for (NPCData npc : npcs) {
                if (slot > 43) break;
                if (slot % 9 == 0 || slot % 9 == 8) slot++;
                inv.setItem(slot++, makeItem(Material.PLAYER_HEAD, "§e§l" + npc.getName(),
                        "§7World: §f" + (npc.getLocation().getWorld() != null ? npc.getLocation().getWorld().getName() : "none"),
                        "",
                        "§c[Left-Click] §7Delete"));
            }
        }
        inv.setItem(49, makeItem(Material.ARROW, "§c§lBack"));
        player.openInventory(inv);
    }

    private ItemStack makeItem(Material m, String n, String... l) {
        ItemStack i = new ItemStack(m);
        ItemMeta meta = i.getItemMeta();
        meta.displayName(Component.text(n));
        meta.lore(Arrays.stream(l).map(Component::text).toList());
        i.setItemMeta(meta);
        return i;
    }
    private void fill(Inventory inv, int size, Material m) {
        ItemStack g = makeItem(m, "§r");
        for (int i=0; i<size; i++) if (i<9||i>=size-9||i%9==0||i%9==8) inv.setItem(i, g);
    }
    private void fillRow(Inventory inv, int r, Material m) {
        ItemStack g = makeItem(m, "§r");
        for (int i=r*9; i<r*9+9; i++) inv.setItem(i, g);
    }
}
